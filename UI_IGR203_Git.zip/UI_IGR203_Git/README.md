# UI_IGR203

UI application that help restaurant waiters to register orders easily.
